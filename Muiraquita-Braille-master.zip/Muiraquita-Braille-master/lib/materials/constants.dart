import 'package:flutter/material.dart';

//background for the enteire app
var backGroundColor = Colors.grey[300];

//Color for all buttons
var buttomColor = Colors.black87;
