package com.example.muiraquita_braille

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
